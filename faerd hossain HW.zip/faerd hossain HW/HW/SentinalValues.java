package sentinalvalues;

import java.util.Scanner;

public class SentinalValues {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        int num = 0;
        while (true) {
            System.out.println("Write your number ");
            int answer = input.nextInt();
            if (answer == 0) {
                System.out.println("The sum is:  " + num);
                break;

            }
            num = num + answer;
        }

    }

}
