package stackofintegers;
public class Changes {
    public int newNumber;
}
